<?
$sSectionName = "Кансалтинг";
$arDirProperties = Array(

);
?>